import React, { useEffect, useState } from 'react';
import { Page } from '../types';
import styles from '../style/HomePage.module.css';
import Image from "next/image";
import DiscountOutlinedIcon from '@mui/icons-material/DiscountOutlined';
import Link from 'next/link';
import Payment from './Payment';
import Navbar from './Navbar/page';
import { LiveSessionRequestPOST, LoginWithTokenPOST, SendTempCodePOST } from '@/api';
import PinInput from 'react-pin-input';



interface LoginProps {
    page: Page;
    onContinue: () => void;
}
interface FormErrors {
    email?: string;

}
const Login: React.FC<LoginProps> = ({ page, onContinue }) => {

    const [isFormValid, setIsFormValid] = useState(false);
    const [isPinValid, setIsPinValid] = useState(false);
    const [formData, setFormData] = useState({ name: '', email: '', phone: '', code: '' });
    const [formErrors, setFormErrors] = useState<FormErrors>({});
    const [verification, setVerification] = useState(false);
    const [isButtonDisabled, setIsButtonDisabled] = useState(false);
    const [timer, setTimer] = useState(0);
    const [invalidCode, setInvalidCode] = useState(false)
    const [pinValue, setPinValue] = useState('');



    useEffect(() => {
        if (timer > 0) {
            const intervalId = window.setInterval(() => setTimer((prev) => prev - 1), 1000);
            return () => window.clearInterval(intervalId);
        }
        setIsButtonDisabled(false);
    }, [timer]);

    // Validate email format
    const validateEmail = (email: string): string | undefined => {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
        if (!email) return "Email is required!";
        if (!regex.test(email)) return "This is not a valid email format!";
    };

    // Handle form input change
    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
        const emailError = name === 'email' ? validateEmail(value) : undefined;
        setFormErrors((prev) => ({ ...prev, email: emailError }));
        setIsFormValid(!emailError);
    };

    // Handle PIN input change
    const handlePinChange = (value: string) => {
        setPinValue(value);
        setIsPinValid(value.length === 6);
        setFormData((prev) => ({ ...prev, code: value }));
    };

    // Submit email for verification code
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            // await SendTempCodePOST(formData.email);
            setVerification(true);
        } catch (error) {
            console.error('Error during submission:', error);
        }
    };

    // Verify the entered code
    const handleVerification = async () => {
        try {
            setInvalidCode(false);
            const { email, code } = formData;
            const response = await LoginWithTokenPOST(email, code.toLowerCase());
            window.localStorage.setItem("accessToken", response.data.data.accessToken);
            window.location.href = "/try-demo-now";
        } catch (error) {
            setInvalidCode(true);
            setIsPinValid(false);
        }
    };

    return (
        <>
            {
                !verification ?
                    <>
                        < Navbar />
                        <div className={styles.homePage}>
                            <div className={styles.container}>
                                <main className={styles.main}>
                                    <div className={styles.content}>
                                        <>
                                            <>
                                                <h1 className={styles.title}>
                                                    Login to continue with you meditation sessions
                                                </h1>
                                                <h2 className={styles.subTitle}>
                                                    Discover a deeper connection to yourself, bliss begins here...
                                                </h2>
                                            </>
                                            <form onSubmit={handleSubmit} className={styles.formContainer}>
                                                <div className={styles.inputGroup}>
                                                    <label htmlFor='email'></label>
                                                    <input
                                                        type="email"
                                                        name="email"
                                                        placeholder='Email Address'
                                                        className={styles.Input}
                                                        value={formData.email}
                                                        required
                                                        onChange={handleInputChange}
                                                    />

                                                    {formErrors.email ? (
                                                        <div className={styles.message_error}>
                                                            <span className="text-danger1">
                                                                {formErrors.email}
                                                            </span>
                                                        </div>
                                                    ) : (
                                                        <div style={{ height: '1.6rem' }}></div>

                                                    )}
                                                </div>
                                                <div className={styles.inputGroup}>
                                                    <button
                                                        className={`${styles.ctaButton} ${styles.buttonWidth}`}
                                                        type="submit"
                                                        disabled={!isFormValid}
                                                        style={{
                                                            opacity: !isFormValid ? 0.5 : 1,
                                                            cursor: !isFormValid ? 'not-allowed' : 'pointer',
                                                        }}
                                                    >
                                                        Login
                                                    </button>


                                                </div>
                                            </form>

                                        </>
                                        <div className={styles.newUser}>
                                            <p className={styles.alreadyMember}>New user?</p>
                                            <Link href="/"> <button className={styles.loginLink}>Sign up</button></Link>
                                        </div>
                                    </div>
                                </main>
                            </div>
                        </div>
                    </>
                    :
                    <>
                        <div className={styles.homePage}>
                            <div className={styles.container}>
                                <main className={styles.main}>
                                    <div className={styles.content} style={{ justifyContent: 'space-between', minHeight: '87vh' }}>

                                        <div>
                                            <>
                                                <h1 className={styles.title} style={{ fontSize: '24px', lineHeight: '30px', marginTop: '30px', marginBottom: '12px' }}>
                                                    Verify Phone Number
                                                </h1>
                                                <h2 className={styles.subTitle} style={{ marginBottom: '34px' }}>
                                                    Code has been sent to {localStorage.getItem('useremail')}
                                                </h2>
                                            </>
                                            <PinInput
                                                length={6}
                                                initialValue={pinValue}
                                                onChange={handlePinChange}
                                                type="custom"
                                                inputMode="text"
                                                style={{ marginBottom: '12px' }}
                                                inputStyle={{ borderColor: '#a6d6e1', borderRadius: '12px', textTransform: 'lowercase' }}
                                                inputFocusStyle={{ borderColor: '#2099b3', textTransform: 'lowercase' }}
                                                onComplete={(value, index) => { }}
                                                autoSelect={true}
                                                regexCriteria={/^[ A-Za-z0-9_@./#&+-]*$/}
                                            />

                                            {invalidCode ?
                                                <div className="text-center">
                                                    <h1 className={styles.message_error}>
                                                        <span>Please enter a valid OTP.</span>
                                                    </h1>
                                                </div>
                                                : <>
                                                    <button type="button" className={styles.resendOTPBtn} disabled={isButtonDisabled} onClick={async () => {

                                                        setIsButtonDisabled(true);
                                                        setTimer(30);
                                                        const userEmail = formData.email;
                                                        await SendTempCodePOST(userEmail);

                                                    }}>
                                                        {isButtonDisabled ? `Resend OTP in ${timer} seconds` : "Resend OTP"}
                                                    </button>
                                                </>
                                            }

                                        </div>
                                        <div className={styles.inputGroup}>
                                            <div className={styles.buttonContainer} style={{ flexDirection: 'row' }}>

                                                <button className={`${styles.firstCta} ${styles.ctaButton}`} onClick={() => { setVerification(false) }}  >
                                                    Back
                                                </button>

                                                <button className={`${styles.secondCta} ${styles.ctaButton}`} disabled={!isPinValid}
                                                    style={{
                                                        opacity: !isPinValid ? 0.5 : 1,
                                                        cursor: !isPinValid ? 'not-allowed' : 'pointer',
                                                    }} onClick={handleVerification} >
                                                    Verify
                                                </button>
                                            </div>

                                        </div>
                                    </div>
                                </main>
                            </div>
                        </div>
                    </>
            }
        </>
    );
};

export default Login;