"use client";

import AgoraRTC, {
    AgoraRTCProvider,
    useJoin,
    useLocalMicrophoneTrack,
    usePublish,
    useRTCClient,
    useRemoteAudioTracks,
    useRemoteUsers
} from "agora-rtc-react";
import styles from '../../style/SixthPage.module.css';
import { EndAllSessionPOST, EndExpiredRequestPOST } from "@/api";
import { useState, useEffect } from "react";
import Image from "next/image";
import DiscountOutlinedIcon from '@mui/icons-material/DiscountOutlined';
const agoraToken = localStorage.getItem("agoraToken");




function Call(props: { appId: string; channelName: string; agoraToken: string }) {
    const client = useRTCClient(
        AgoraRTC.createClient({ codec: "vp8", mode: "rtc" })
    );

    return (
        <AgoraRTCProvider client={client}>
            <Videos channelName={props.channelName} AppID={props.appId} AgoraToken={props.agoraToken} />
        </AgoraRTCProvider>
    );
}

function Videos(props: { channelName: string; AppID: string; AgoraToken: string }) {
    const [isMuted, setIsMuted] = useState(false);
    const [isHeadset, setIsHeadset] = useState(false);
    const [isLocalSpeaking, setIsLocalSpeaking] = useState(false);
    const [speakingRemoteUsers, setSpeakingRemoteUsers] = useState<string[]>([]);
    const { AppID, channelName } = props;
    const { isLoading: isLoadingMic, localMicrophoneTrack } = useLocalMicrophoneTrack();
    // const { isLoading: isLoadingCam, localCameraTrack } = useLocalCameraTrack();
    const [networkQuality, setNetworkQuality] = useState('stable'); // Add state for network quality
    const [selectedPlan, setSelectedPlan] = useState(6);
    const [plans, setPlans] = useState(false); // Add state for network quality
    const [elapsedTime, setElapsedTime] = useState(0);



    const client = useRTCClient(); // Get the RTC client instance

    const remoteUsers = useRemoteUsers();
    const { audioTracks } = useRemoteAudioTracks(remoteUsers);

    useJoin({
        appid: AppID,
        channel: channelName,
        token: agoraToken,
    });
    usePublish([localMicrophoneTrack]);

    const deviceLoading = isLoadingMic;
    useEffect(() => {
        if (!client) return;

        const handleNetworkQuality = (quality: number) => {

            if (quality >= 3) {
                setNetworkQuality('poor');
            } else {
                setNetworkQuality('stable');
            }
        };

        // Listen for network quality changes
        client.on('network-quality', (stats) => {
            handleNetworkQuality(stats.downlinkNetworkQuality);
        });


        // Cleanup listener on component unmount
        return () => {
            client.off('network-quality', handleNetworkQuality);
        };
    }, [client]);
    useEffect(() => {
        let timerInterval: NodeJS.Timeout | null = null;

        if (localMicrophoneTrack) {
            // Start the timer when the microphone track is loaded
            timerInterval = setInterval(() => {
                setElapsedTime((prevTime) => prevTime + 1); // Increment elapsed time every second
            }, 1000);
        }

        return () => {
            if (timerInterval) {
                clearInterval(timerInterval); // Clear timer when the component unmounts or the call ends
            }
        };
    }, [localMicrophoneTrack]);

    // Monitor local user speaking
    useEffect(() => {
        const intervalId = setInterval(() => {
            if (localMicrophoneTrack) {
                const volumeLevel = localMicrophoneTrack.getVolumeLevel();
                setIsLocalSpeaking(volumeLevel > 0.6);
            }
        }, 500);

        return () => clearInterval(intervalId);
    }, [localMicrophoneTrack]);

    // Monitor remote users speaking
    useEffect(() => {

        if (audioTracks.length === 0) return;

        const intervalId = setInterval(() => {
            const speakingUsers = audioTracks
                .filter(track => track.getVolumeLevel() > 0.6)
                .map(track => track.getUserId().toString()); // Convert number to string
            setSpeakingRemoteUsers(speakingUsers);
        }, 500);

        return () => clearInterval(intervalId);
    }, [audioTracks]);
    useEffect(() => {
        let pollingInterval: any;

        const checkHeadset = async () => {
            try {
                await navigator.mediaDevices.getUserMedia({ audio: true });

                const devices = await navigator.mediaDevices.enumerateDevices();
                const audioInputs = devices.filter(device => device.kind === 'audioinput' || device.kind === 'audiooutput');

                const headsetDevice = audioInputs.filter(device =>
                    (device.label.toLowerCase().includes('headset') ||
                        device.label.toLowerCase().includes('wired ') ||
                        device.label.toLowerCase().includes('bluetooth') ||
                        device.label.toLowerCase().includes('headphone') ||
                        device.label.toLowerCase().includes('handsfree') ||
                        device.label.toLowerCase().includes('earbud') ||
                        device.label.toLowerCase().includes('earphones') ||
                        device.label.toLowerCase().includes('airpods')) &&
                    !device.label.toLowerCase().includes('earpiece')
                );

                setIsHeadset(headsetDevice.length > 0);
            } catch (error) {
                console.error('Error accessing media devices:', error);
            }
        };

        checkHeadset();

        if ('mediaDevices' in navigator && 'ondevicechange' in navigator.mediaDevices) {
            navigator.mediaDevices.addEventListener('devicechange', checkHeadset);
        } else {
            // Fallback to polling if 'devicechange' is not supported
            pollingInterval = setInterval(checkHeadset, 500);
        }

        // Cleanup event listener on component unmount
        return () => {
            if (pollingInterval) {
                clearInterval(pollingInterval);
            }
        };
    }, []);

    const handleEndCall = async (e: any) => {
        e.preventDefault();
        try {
            await EndAllSessionPOST();
            await EndExpiredRequestPOST();
            setElapsedTime(0);
            window.location.href = "/buy-plans";
        } catch (error) {
            console.error('Submission error:', error);
        }
    };
    const toggleMute = () => {
        if (isMuted) {
            localMicrophoneTrack?.setMuted(false);
        } else {
            localMicrophoneTrack?.setMuted(true);
        }
        setIsMuted(!isMuted);
    };
    const togglePlan = () => {
        setPlans(!plans)
    };
    const handlePlanSelect = (plan: any) => {
        setSelectedPlan(plan);
    };

    audioTracks.map((track) => track.play());
    if (deviceLoading)
        return (
            <div className={styles.loading_container}>Loading devices...</div>
        );
    const formatTime = (seconds: number) => {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
    };
    return (
        <div className={styles.video_grid_container}>
            {localMicrophoneTrack ? <>
                <div className={`${styles.video_grid} ${styles.local_video}`}>
                    <div className={styles.teacherNameContainer}>
                        <span>{localStorage.getItem("classCoach")}</span>
                        <p>Your Bliss Partner</p>
                        <p>{formatTime(elapsedTime)}</p>
                        {/* <p>{networkQuality === 'poor' ? 'Connection Poor' : 'Connection Stable'}</p> */}
                    </div>


                    <div className={styles.image_container}>
                        <Image src="/assets/images/TeacherImage.png" width={150} height={150} alt="Pranab Dash" className={styles.avatar} />
                    </div>
                </div>

                <button className={styles.ctaButton} style={{ marginTop: '8rem' }} onClick={() => { window.open("/buy-plans", "_blank"); }}>
                    Buy Bliss
                </button>
                <div className={styles.end_call_button}>
                    <div className={styles.buttonContainer}>
                        <button
                            className={styles.end_call_link} style={{ background: "white" }}

                        >
                            {isHeadset ?
                                <span> <Image src="/assets/images/bluetoothIcon.png" width={60} height={60} alt="icon" className={styles.img} /> </span>
                                :
                                <span ><Image src="/assets/images/SpeakerIcon.png" width={60} height={60} alt="icon" className={styles.img} /></span>
                            }
                        </button>
                        <button
                            className={styles.end_call_link}
                            onClick={handleEndCall}
                        >
                            <span ><Image src="/assets/images/endcallIcon.png" width={60} height={60} alt="icon" /></span>

                        </button>
                        <button
                            className={styles.end_call_link} style={{ background: "white" }}
                            onClick={toggleMute}
                        >
                            {isMuted ?
                                <span ><Image src="/assets/images/MicOffIcon.png" width={60} height={60} alt="icon" className={styles.img} /></span>
                                :
                                <span ><Image src="/assets/images/MicIcon.png" width={60} height={60} alt="icon" className={styles.img} /></span>
                            }
                        </button>

                    </div>
                </div>
            </>
                : null}
        </div>
    );
}

export default Call;
