'use client';
import { Provider } from 'react-redux';
import { store } from '@/store';
import posthog from 'posthog-js';
import { PostHogProvider } from 'posthog-js/react';

if (typeof window !== 'undefined') {
    posthog.init(process.env.NEXT_PUBLIC_POSTHOG_KEY!, {
        api_host: process.env.NEXT_PUBLIC_POSTHOG_HOST,
        person_profiles: 'identified_only', // or 'always'
    });
}

export function Providers({ children }: { children: React.ReactNode }) {
    return (
        <Provider store={store}>
            <PostHogProvider client={posthog}>{children}</PostHogProvider>
        </Provider>
    );
}
