"use client"; // This is a client component

import { useEffect, useState } from 'react';
import Navbar from '@/components/Navbar/page';

interface ClientWrapperProps {
    children: React.ReactNode;
}

const ClientWrapper: React.FC<ClientWrapperProps> = ({ children }) => {
    const [showNavbar, setShowNavbar] = useState(false);

    useEffect(() => {
        
        setInterval(() => {
            const token = localStorage.getItem("accessToken");
            const LiveRequestStatus = localStorage.getItem("LiveRequestStatus");            
            
            if (!token || LiveRequestStatus === 'WAITING_COACH_CONFIRMATION') {
                setShowNavbar(true);
            } 
            if (LiveRequestStatus === 'ACCEPTED') {
                setTimeout(() => {
                    setShowNavbar(false);
                }, 2000);
            } 
           
        }, 500);
        
    }, []);
   

    return (
        <>
            {/* {showNavbar && <Navbar />} */}
            {children}
        </>
    );
};

export default ClientWrapper;
