'use client';
import React, { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { Page } from '../types';
import Link from "next/link";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import { doc, collection, onSnapshot, getDoc, getDocs, setDoc, addDoc } from "firebase/firestore";
import { auth, fireDatabase } from "./firebase/firebaseConfig";
import { getAuth, getIdToken, onAuthStateChanged, signInAnonymously, signInWithCustomToken } from "firebase/auth";


import Styles from '../style/SixthPage.module.css'
import { JoinLivePOST, LiveSessionRequestGET, EndAllSessionPOST, LiveSessionRequestPOST, EndExpiredRequestPOST, GetFirebaseTokenPOST } from "../api/index";
import { styleText } from "util";
import Navbar from "./Navbar/page";

const Call = dynamic(() => import('./agoraDashboard/Call'), { ssr: false });
const MemoizedCall = React.memo(Call);

interface SixthPageProps {
    page: Page;
    onContinue: () => void;
}

const SixthPage: React.FC<SixthPageProps> = ({ page, onContinue }) => {
    const [liveSessionId, setLiveSessionId] = useState<string | null>(null);
    const [agoraToken, setAgoraToken] = useState<string | null>(null);
    const [liveRequestStatus, setLiveRequestStatus] = useState<string | null>(null);
    const [isCallReady, setIsCallReady] = useState<boolean>(false);
    const [microphoneAllowed, setMicrophoneAllowed] = useState<boolean>(false);
    const [breathIn, setBreathIn] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response1 = await LiveSessionRequestGET();
                const newStatus = response1.data.data.rs;
                localStorage.setItem("LiveRequestStatus", newStatus);
                setLiveRequestStatus(newStatus);

                if (newStatus === 'ACCEPTED') {
                    localStorage.setItem("LiveSessionId", response1.data.data.lsId);
                    const response = await JoinLivePOST();
                    const newAgoraToken = response.data.data.props.agoraToken;
                    localStorage.setItem("agoraToken", newAgoraToken);
                    setAgoraToken(newAgoraToken);

                    const userObject = response.data.data.participants[0];
                    const tutorObject = response.data.data.participants[response.data.data.participants.length - 1];
                    console.log("userObject", userObject.user.name);
                    console.log("tutorObject", tutorObject.user.name);
                    localStorage.setItem("classCoach", tutorObject.user.name);

                    const newLsId = response.data.data.id;
                    localStorage.setItem("LiveSessionId", newLsId);
                    setLiveSessionId(newLsId);
                    clearInterval(pollInterval);

                } else if (newStatus === 'FAILED') {
                    try {
                        await EndAllSessionPOST();
                        await EndExpiredRequestPOST();
                        console.log("Session ended");
                    } catch (error) {
                        console.error('Submission error:', error);
                    }
                }
            } catch (error) {
                console.error('Polling error:', error);
            }
            return () => clearInterval(pollInterval);
        };

        // Call fetchData immediately
        fetchData();

        // Set up polling interval
        const pollInterval = setInterval(async () => {
            await fetchData();
        }, 5000);

        // Cleanup interval on unmount
        return () => clearInterval(pollInterval);

    }, []);

    // useEffect(() => {
    //     async function authenticateUser(token: any) {
    //         try {
    //             const userCredential = await signInWithCustomToken(auth, token);
    //             console.log("Authenticated user:", userCredential.user);
    //             return userCredential.user;
    //         } catch (error) {
    //             console.error("Error authenticating user:", error);
    //         }
    //     }
    //     let token = localStorage.getItem("firebaseToken");
    //     console.log('token', token);

    //     if (token) {
    //         authenticateUser(token);
    //     } else {
    //         console.log("No token found");
    //     } const unsubscribeAuth = auth.onAuthStateChanged((user) => {
    //         if (user) {
    //             console.log("User signed in:", user.uid);

    //             const setData = async () => {
    //                 try {
    //                     const docRef = await addDoc(collection(fireDatabase, "liveRequests"), {
    //                         name: "John Doe",
    //                         age: 30,
    //                         location: "New York"
    //                     });
    //                     console.log("Document written with ID: ", docRef.id);
    //                 } catch (error) {
    //                     console.error("Error adding document: ", error);
    //                 }
    //             };

    //             setData();
    //         } else {
    //             console.log("User not signed in");
    //         }
    //     });

    //     // Cleanup the Auth state listener on component unmount
    //     return () => unsubscribeAuth();
    // }, []);

    useEffect(() => {

        const interval = setInterval(() => {
            setBreathIn((prev) => !prev);
        }, 2000);

        return () => clearInterval(interval);
    }, []);

    useEffect(() => {
        if (agoraToken) {
            setTimeout(() => {
                setIsCallReady(true);
            }, 1500);
        }
    }, [agoraToken]);

    const handleAgain = async (e: any) => {
        e.preventDefault();
        try {
            const response = await LiveSessionRequestPOST();
            if (response) {
                window.location.reload();
            }
            // onContinue();
        } catch (error) {
            console.error('Submission error:', error);
        }

    };
    // Function to request microphone access
    const allowMicrophone = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            console.log("Microphone access granted");
            setMicrophoneAllowed(true);
        } catch (error) {
            console.error("Microphone access denied:", error);
        }
    };

    // Check if microphone permission is already granted
    useEffect(() => {
        const checkMicrophonePermission = async () => {
            try {
                const permissionStatus = await navigator.permissions.query({ name: 'microphone' as any });
                if (permissionStatus.state === 'granted') {
                    setMicrophoneAllowed(true);
                }
            } catch (error) {
                console.error('Error checking microphone permission:', error);
            }
        };

        checkMicrophonePermission();
    }, []);

    var settings = {
        infinite: true,
        autoplay: true,
        speed: 500,
        autoplaySpeed: 4000,
        slidesToShow: 1,
        centerPadding: "10",
        slidesToScroll: 1,
        cssEase: "ease",
        arrows: false,
        dots: true,
        responsive: [
            {
                breakpoint: 700,
                settings: {
                    initialSlide: 1,
                    centerMode: false,
                },
            },
        ]
    };

    return (
        <>
            <div className={Styles.container}>
                <div className={Styles.main}>
                    <div className={Styles.content}>
                        <>
                            {liveRequestStatus === 'FAILED' ?
                                <>
                                    <div className={Styles.tryAgainBlock}>
                                        <span>No coach available, would you like to retry</span>
                                        <button onClick={handleAgain}>Try Again</button>
                                        <button className={Styles.tryAgainBack} onClick={() => { window.location.href = '/' }}>Go Back</button>
                                    </div>
                                </>
                                :
                                <>

                                    {!isCallReady ?
                                        <>
                                            
                                            <div className={Styles.TextContainer}>
                                                <h1>{breathIn ? 'Breath in' : 'Breath out'}</h1>
                                                <p>While we're connecting you to your
                                                    meditation coach</p></div>
                                            {/* {!microphoneAllowed && (
                                                <button onClick={allowMicrophone} className={Styles.allowMicrophoneBtn}>
                                                    Allow Microphone
                                                </button>
                                            )} */}
                                            <div className={Styles.videoContainer}>
                                                <video
                                                    src="/assets/images/meditation.mp4"
                                                    autoPlay
                                                    loop
                                                    muted
                                                    playsInline
                                                    className={Styles.video}>
                                                </video>
                                            </div>


                                             {/* <div className={Styles.quoteContainer}>
                                                <Slider {...settings}>
                                                <figure className={Styles.quote}>
                                                    <p>"Language learning can delay cognitive decline."</p>
                                                    <p>- Psychological Science</p>
                                                </figure>
                                                <figure className={Styles.quote}>
                                                    <p>"OtoLingo users save ~25 hours each month by multitasking"</p>
                                                    <p>- Our Data Analyst</p>
                                                </figure>
                                                <figure className={Styles.quote}>
                                                    <p>"Bilingualism increases cognitive control and efficiency"</p>
                                                    <p>- Journal of Neuroscience</p>
                                                </figure>
                                                </Slider>

                                            </div>  */}
                                        </>
                                        :
                                        null
                                    }
                                    {liveSessionId && agoraToken && (
                                        <div style={{ display: isCallReady ? 'block' : 'none', width: '100%' }}>
                                            <MemoizedCall
                                                appId={process.env.NEXT_PUBLIC_AGORA_APP_ID as string}
                                                channelName={liveSessionId}
                                                agoraToken={agoraToken}
                                            />
                                        </div>
                                    )}
                                </>
                            }
                        </>
                    </div>
                </div>
            </div>
        </>
    );
};

export default SixthPage;