import './globals.css';
import { Providers } from '@/components/Providers';
import Navbar from '@/components/Navbar/page';
import { Metadata } from 'next';
import ClientWrapper from '../components/ClientWrapper'; // Import the new client wrapper

export const metadata: Metadata = {
    title: "OtoCoach",
    description: ""
};

export default function RootLayout({
    children,
}: {
    children: React.ReactNode
}) {
    return (
        <html lang="en">
            <body>
                <Providers>
                    <ClientWrapper>
                        <div className="container">
                            {children}
                        </div>
                    </ClientWrapper>
                </Providers>
            </body>
        </html>
    );
}
