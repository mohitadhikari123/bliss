import axios from "axios";
import { Page } from "@/types";
const API_BASE_URL = "https://ac-api-dev.newlearn.tech";

const mock = true;

interface RegisterData {
  user: {
    name: string;
    email: string;
    mobile: string;
  };
  data: {
    QUESTION_1_KEY: string;
    QUESTION_2_KEY: string;
  };
}
interface AddCustomerData {
  data: {
    REMINDER_TIME: string;
  };
}
const RegisterPOST = async ({ user, data }: RegisterData) => {
  const config = {
    method: "post",
    url: `${API_BASE_URL}/customers/register`,
    headers: {
      "Content-Type": "application/json",
    },
    data: JSON.stringify({ user, data }),
    timeout: 10000,
  };
  try {
    const response = await axios(config);
    window.localStorage.setItem("accessToken", response.data.data.accessToken);
    console.log(JSON.stringify(response.data.data.accessToken));
  } catch (error: any) {
    if (error.code === "ECONNABORTED") {
      throw new Error("The request took too long. Please try again later.");
    } else {
      throw new Error("An error occurred: " + error.message);
    }
  }
};
const LiveSessionRequestPOST = async () => {
  const config = {
    method: "post",
    url: `${API_BASE_URL}/liveSessionRequest/create`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
    },
  };
  try {
    const response = await axios(config);
    window.localStorage.setItem("LiveRequestId", response.data.data.id);
    console.log(JSON.stringify(response.data));
    return response; // Return the response object
  } catch (error) {
    console.log(error);
    throw error; // Ensure errors are thrown so they can be caught
  }
};
const LiveSessionRequestGET = async (): Promise<any> => {
  const config = {
    method: "get",
    url: `${API_BASE_URL}/liveSessionRequest/${localStorage.getItem(
      "LiveRequestId"
    )}/getStatus`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
    },
  };

  try {
    const response = await axios(config);
    console.log(JSON.stringify(response.data.data.rs));
    window.localStorage.setItem("LiveRequestStatus", response.data.data.rs);
    return response; // Return the response object
  } catch (error) {
    console.log(error);
    throw error; // Ensure errors are thrown so they can be caught
  }
};
const JoinLivePOST = async () => {
  const config = {
    method: "post",
    url: `${API_BASE_URL}/liveSession/${localStorage.getItem(
      "LiveSessionId"
    )}/join`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
    },
  };
  try {
    const response = await axios(config);
    window.localStorage.setItem(
      "agoraToken",
      response.data.data.props.agoraToken
    );
    console.log(JSON.stringify(response.data.data.props.agoraToken));
    return response; // Return the response
  } catch (error) {
    console.log(error);
    throw error; // Rethrow the error so the calling code can handle it
  }
};
const EndAllSessionPOST = async (): Promise<any> => {
  const config = {
    method: "post",
    url: `${API_BASE_URL}/liveSession/endAllSessions`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
    },
  };

  try {
    const response = await axios(config);
    window.localStorage.removeItem("agoraToken");
    window.localStorage.removeItem("LiveSessionId");
    window.localStorage.removeItem("LiveRequestStatus");
    window.localStorage.removeItem("LiveRequestId");
    console.log(JSON.stringify(response.data));

    return response; // Return the response object
  } catch (error) {
    console.log(error);
    throw error; // Ensure errors are thrown so they can be caught
  }
};
const SendTempCodePOST = async (email: string) => {
  const data = JSON.stringify({
    email: email,
    domain: "CUSTOMER",
  });
  const config = {
    method: "post",
    url: `${API_BASE_URL}/users/sendTempCode`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
    },
    data: data,
    timeout: 10000,
  };
  try {
    const response = await axios(config);
    console.log(JSON.stringify(response.data));
    return response; // Return the response object
  } catch (error) {
    console.log(error);
    throw error; // Ensure errors are thrown so they can be caught
  }
};
const LoginWithTokenPOST = async (email: string, tempCode: string) => {
  const data = JSON.stringify({
    email: email,
    tempCode: tempCode,
  });
  console.log("data", data);
  const config = {
    method: "post",
    url: `${API_BASE_URL}/customers/loginWithTempCode`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
    },
    data: data,
    timeout: 10000,
  };

  try {
    const response = await axios(config);
    console.log(JSON.stringify(response.data.data.rs));
    return response; // Return the response object
  } catch (error) {
    console.log(error);
    console.log(error);
    throw error; // Ensure errors are thrown so they can be caught
  }
};
const EndExpiredRequestPOST = async () => {
  const config = {
    method: "post",
    url: `${API_BASE_URL}/liveSessionRequest/endExpiredRequests`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
    },
  };
  try {
    const response = await axios(config);
    console.log(JSON.stringify(response.data));
    return response; // Return the response object
  } catch (error) {
    console.log(error);
    throw error; // Ensure errors are thrown so they can be caught
  }
};
const GetFirebaseTokenPOST = async () => {
  const config = {
    method: "post",
    url: `${API_BASE_URL}/users/getFirebaseToken`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
    },
  };
  try {
    const response = await axios(config);
    window.localStorage.setItem("firebaseToken", response.data.data);
    console.log(JSON.stringify(response.data));
    return response.data.data; // Return the response object
  } catch (error) {
    console.log(error);
    throw error; // Ensure errors are thrown so they can be caught
  }
};
const GetAnyCoachAvailable = async () => {
  const config = {
    method: "get",
    url: `${API_BASE_URL}/availability/isAnyCoachAvailableNow`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
    },
  };
  try {
    const response = await axios(config);
    window.localStorage.setItem(
      "isTutorAvailable",
      response.data.data.isAvailable
    );
    console.log(JSON.stringify(response.data));
    return response.data; // Return the response object
  } catch (error) {
    console.log(error);
    throw error; // Ensure errors are thrown so they can be caught
  }
};
const AddCustomerDataPOST = async ({ data }: AddCustomerData) => {
  const config = {
    method: "post",
    url: `${API_BASE_URL}/customers/addData`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
    },
    data: JSON.stringify({ data }),
    timeout: 10000,
  };
  try {
    const response = await axios(config);
    window.localStorage.setItem("accessToken", response.data.data.accessToken);
    console.log(JSON.stringify(response.data.data.accessToken));
  } catch (error: any) {
    if (error.code === "ECONNABORTED") {
      throw new Error("The request took too long. Please try again later.");
    } else {
      throw new Error("An error occurred: " + error.message);
    }
  }
};
export {
  RegisterPOST,
  LoginWithTokenPOST,
  SendTempCodePOST,
  LiveSessionRequestPOST,
  LiveSessionRequestGET,
  JoinLivePOST,
  EndAllSessionPOST,
  EndExpiredRequestPOST,
  GetFirebaseTokenPOST,
  GetAnyCoachAvailable,
  AddCustomerDataPOST,
};

export const fetchPages = async (): Promise<Page[]> => {
  if (mock) {
    return [
      {
        id: "1",
        slug: "",
        title: "Learn German Anywhere, Anytime",
        description: "On-Demand German speakers available 24/7",
        type: "HOME",
        questions: [
          {
            id: "1",
            text: "Question 1",
            type: "SELECT_BUTTON",
            options: {
              yes: "Yes",
              no: "No",
            },
          },
          {
            id: "2",
            text: "Question 2",
            type: "SELECT_BUTTON",
            options: {
              yes: "Yes",
              no: "No",
            },
          },
        ],
      },
      {
        id: "2",
        slug: "try-demo-now",
        title: "First Class is Free!!",
        description:
          "Do You have 15 minute of time to take class over a Audio only Call.",
        type: "SECOND",
        questions: [
          {
            id: "1",
            text: "Question 1",
            type: "SELECT_BUTTON",
            options: {
              yes: "Yes",
              no: "No",
            },
          },
          {
            id: "2",
            text: "Question 2",
            type: "SELECT_BUTTON",
            options: {
              yes: "Yes",
              no: "No",
            },
          },
        ],
      },

      {
        id: "3",
        slug: "live-session",
        title: "Continue",
        description: "Connecting to Your German Tutor",
        type: "THIRD",
        questions: [
          {
            id: "1",
            text: "Question 1",
            type: "SELECT_BUTTON",
            options: {
              yes: "Yes",
              no: "No",
            },
          },
          {
            id: "2",
            text: "Question 2",
            type: "SELECT_BUTTON",
            options: {
              yes: "Yes",
              no: "No",
            },
          },
        ],
      },
      {
        id: "4",
        slug: "buy-plans",
        title: "Continue",
        description: "Connecting to Your German Tutor",
        type: "ZERO",
        questions: [
          {
            id: "1",
            text: "Question 1",
            type: "SELECT_BUTTON",
            options: {
              yes: "Yes",
              no: "No",
            },
          },
          {
            id: "2",
            text: "Question 2",
            type: "SELECT_BUTTON",
            options: {
              yes: "Yes",
              no: "No",
            },
          },
        ],
      },
      {
        id: "5",
        slug: "maybe-later",
        title: "Continue",
        description: "Connecting to Your German Tutor",
        type: "MBL",
        questions: [
          {
            id: "1",
            text: "Question 1",
            type: "SELECT_BUTTON",
            options: {
              yes: "Yes",
              no: "No",
            },
          },
          {
            id: "2",
            text: "Question 2",
            type: "SELECT_BUTTON",
            options: {
              yes: "Yes",
              no: "No",
            },
          },
        ],
      },
      {
        id: "6",
        slug: "login",
        title: "Continue",
        description: "Connecting to Your German Tutor",
        type: "LOGIN",
        questions: [
          {
            id: "1",
            text: "Question 1",
            type: "SELECT_BUTTON",
            options: {
              yes: "Yes",
              no: "No",
            },
          },
          {
            id: "2",
            text: "Question 2",
            type: "SELECT_BUTTON",
            options: {
              yes: "Yes",
              no: "No",
            },
          },
        ],
      },
    ];
  }
  const response = await axios.get(`${API_BASE_URL}/pages`);
  return response.data;
};

export const saveAnswers = async (
  pageId: string,
  answers: Record<string, string>
): Promise<void> => {
  console.log("SaveAnswer   : ", answers);

  if (mock) {
    return;
  }
  await axios.post(`${API_BASE_URL}/pages/${pageId}/answers`, answers);
};
